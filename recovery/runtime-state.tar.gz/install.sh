#!/usr/bin/env bash
set -Eeuo pipefail

trap 'echo "Installation failed near line $LINENO." >&2' ERR

log() {
    echo
    echo "==> $*"
}

fail() {
    echo "ERROR: $*" >&2
    exit 1
}

if [[ "$EUID" -ne 0 ]]; then
    exec sudo -E bash "$0" "$@"
fi

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_OWNER="$(stat -c '%U' "$PROJECT_ROOT")"

if [[ -n "${SUDO_USER:-}" && "$SUDO_USER" != "root" ]]; then
    APP_USER="$SUDO_USER"
elif [[ "$PROJECT_OWNER" != "root" ]]; then
    APP_USER="$PROJECT_OWNER"
elif id ubuntu >/dev/null 2>&1; then
    APP_USER="ubuntu"
else
    APP_USER="root"
fi

APP_GROUP="$(id -gn "$APP_USER")"
APP_HOME="$(getent passwd "$APP_USER" | cut -d: -f6)"

MODEL_ROOT="${YOUTUBE_AI_MODEL_ROOT:-$(dirname "$PROJECT_ROOT")/models}"
VENV="$PROJECT_ROOT/.venv"
PYTHON="$VENV/bin/python"
PIP="$VENV/bin/pip"

SERVICE_NAME="youtube-ai-generator"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
OLLAMA_MODEL="qwen3:14b"

RECOVERY_ARCHIVE="$PROJECT_ROOT/recovery/runtime-state.tar.gz"
RECOVERY_CHECKSUM="$PROJECT_ROOT/recovery/runtime-state.sha256"

GENERATED_ADMIN_PASSWORD=""
RECOVERY_RESTORED="false"

run_as_user() {
    if [[ "$APP_USER" == "root" ]]; then
        "$@"
    else
        sudo -u "$APP_USER" -H "$@"
    fi
}

restore_recovery_state() {
    if [[ ! -f "$RECOVERY_ARCHIVE" ]]; then
        log "Recovery archive not found; using fresh-install mode"
        return
    fi

    [[ -f "$RECOVERY_CHECKSUM" ]] || \
        fail "Recovery checksum file is missing."

    log "Verifying disaster-recovery archive"

    (
        cd "$PROJECT_ROOT"
        sha256sum -c recovery/runtime-state.sha256
    )

    local recovery_tmp
    recovery_tmp="$(mktemp -d)"

    tar -xzf "$RECOVERY_ARCHIVE" -C "$recovery_tmp"

    [[ -f "$recovery_tmp/.env" ]] || \
        fail "Recovery archive does not contain .env."

    [[ -f "$recovery_tmp/backend/data/app.db" ]] || \
        fail "Recovery archive does not contain the database."

    mkdir -p "$PROJECT_ROOT/backend/data"

    install -o "$APP_USER" -g "$APP_GROUP" -m 600 \
        "$recovery_tmp/.env" \
        "$PROJECT_ROOT/.env"

    install -o "$APP_USER" -g "$APP_GROUP" -m 600 \
        "$recovery_tmp/backend/data/app.db" \
        "$PROJECT_ROOT/backend/data/app.db"

    if [[ -s "$recovery_tmp/huggingface/token" ]]; then
        mkdir -p "$APP_HOME/.cache/huggingface"

        install -o "$APP_USER" -g "$APP_GROUP" -m 600 \
            "$recovery_tmp/huggingface/token" \
            "$APP_HOME/.cache/huggingface/token"
    fi

    rm -rf "$recovery_tmp"

    RECOVERY_RESTORED="true"
    log "Environment, database and saved credentials restored"
}

restore_recovery_state

log "Installing Ubuntu system dependencies"

apt-get update

DEBIAN_FRONTEND=noninteractive apt-get install -y \
    ca-certificates \
    curl \
    git \
    ffmpeg \
    espeak-ng \
    redis-server \
    python3 \
    python3-venv \
    python3-pip \
    python3-dev \
    build-essential \
    libsndfile1 \
    libffi-dev \
    libssl-dev \
    pkg-config \
    sqlite3 \
    unzip

command -v nvidia-smi >/dev/null 2>&1 || \
    fail "NVIDIA driver or GPU was not detected."

log "GPU detected"

nvidia-smi \
    --query-gpu=name,memory.total,driver_version \
    --format=csv,noheader

SWAP_MIN_KB=24000000
SWAP_TOTAL_KB="$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo)"

if (( SWAP_TOTAL_KB >= SWAP_MIN_KB )); then
    log "Existing swap is sufficient; preserving it"
else
    log "Configuring 24 GB swap"

    if [[ -e /swapfile ]]; then
        fail "Existing /swapfile found but active swap is below 24 GB. Inspect it manually."
    fi

    if ! fallocate -l 24G /swapfile; then
        rm -f /swapfile
        dd if=/dev/zero of=/swapfile \
            bs=1M count=24576 status=progress
    fi

    chmod 600 /swapfile
    mkswap /swapfile
    swapon /swapfile

    grep -qE '^/swapfile[[:space:]]' /etc/fstab || \
        echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

log "Swap status"
swapon --show
free -h

log "Creating project directories"

mkdir -p \
    "$MODEL_ROOT/huggingface" \
    "$PROJECT_ROOT/backend/data" \
    "$PROJECT_ROOT/outputs/jobs" \
    "$PROJECT_ROOT/logs"

chown -R "$APP_USER:$APP_GROUP" \
    "$PROJECT_ROOT" \
    "$MODEL_ROOT"

log "Preparing Python virtual environment"

if [[ ! -x "$PYTHON" ]]; then
    run_as_user /usr/bin/python3 -m venv "$VENV"
fi

run_as_user "$PIP" install --upgrade pip setuptools wheel
run_as_user "$PIP" install -r "$PROJECT_ROOT/backend/requirements.txt"

log "Installing isolated Whisper runtime"

run_as_user "$PIP" install --no-deps \
    faster-whisper==1.2.1 \
    ctranslate2==4.8.1 \
    onnxruntime==1.28.0 \
    av==18.0.0 \
    flatbuffers==25.12.19

log "Preparing Whisper caption model"

WHISPER_MODEL_DIR="$MODEL_ROOT/whisper/small.en"

mkdir -p "$WHISPER_MODEL_DIR"
chown -R "$APP_USER:$APP_GROUP" "$MODEL_ROOT/whisper"

if [[ -d "$APP_HOME/.cache/huggingface" ]]; then
    chown -R "$APP_USER:$APP_GROUP" "$APP_HOME/.cache/huggingface"
    chmod 700 "$APP_HOME/.cache/huggingface"
fi

if [[ -f "$APP_HOME/.cache/huggingface/token" ]]; then
    chmod 600 "$APP_HOME/.cache/huggingface/token"
fi

WHISPER_MODEL_FILE="$WHISPER_MODEL_DIR/model.bin"
WHISPER_MODEL_MIN_BYTES=100000000
WHISPER_MODEL_BYTES="$(
    stat -c%s "$WHISPER_MODEL_FILE" 2>/dev/null || echo 0
)"

if (( WHISPER_MODEL_BYTES < WHISPER_MODEL_MIN_BYTES )); then
    run_as_user env \
        HF_TOKEN_PATH="$APP_HOME/.cache/huggingface/token" \
        HF_HUB_DISABLE_XET=1 \
        WHISPER_MODEL_DIR="$WHISPER_MODEL_DIR" \
        "$PYTHON" - <<'PYWHISPER'
import os

from huggingface_hub import snapshot_download

snapshot_download(
    repo_id="Systran/faster-whisper-small.en",
    local_dir=os.environ["WHISPER_MODEL_DIR"],
)
PYWHISPER
else
    log "Existing Whisper model preserved"
fi

WHISPER_MODEL_BYTES="$(
    stat -c%s "$WHISPER_MODEL_FILE" 2>/dev/null || echo 0
)"

(( WHISPER_MODEL_BYTES >= WHISPER_MODEL_MIN_BYTES )) ||     fail "Whisper model download is incomplete."

run_as_user "$PIP" check

log "Generating voice previews"

run_as_user env \
    PYTHONPATH="$PROJECT_ROOT/backend" \
    YOUTUBE_AI_PROJECT_ROOT="$PROJECT_ROOT" \
    YOUTUBE_AI_MODEL_ROOT="$MODEL_ROOT" \
    "$PYTHON" "$PROJECT_ROOT/scripts/generate_voice_previews.py"

log "Starting Redis"

systemctl enable --now redis-server

redis-cli ping | grep -q PONG || \
    fail "Redis did not start."

if ! command -v ollama >/dev/null 2>&1; then
    log "Installing Ollama"
    curl -fsSL https://ollama.com/install.sh | sh
fi

log "Starting Ollama"

systemctl enable --now ollama

for _ in $(seq 1 60); do
    if curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
        break
    fi

    sleep 2
done

curl -fsS http://127.0.0.1:11434/api/tags >/dev/null || \
    fail "Ollama did not start."

log "Downloading Ollama model: $OLLAMA_MODEL"

run_as_user ollama pull "$OLLAMA_MODEL"

ENV_FILE="$PROJECT_ROOT/.env"

if [[ ! -f "$ENV_FILE" ]]; then
    log "Creating secure fresh-install environment"

    GENERATED_ADMIN_PASSWORD="$(
        "$PYTHON" -c 'import secrets; print(secrets.token_urlsafe(18))'
    )"

    SECRET_KEY="$(
        "$PYTHON" -c 'import secrets; print(secrets.token_urlsafe(48))'
    )"

    FERNET_KEY="$(
        "$PYTHON" -c \
        'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())'
    )"

    export PROJECT_ROOT
    export GENERATED_ADMIN_PASSWORD
    export SECRET_KEY
    export FERNET_KEY
    export OLLAMA_MODEL

    "$PYTHON" - <<'PYENV'
import json
import os
from pathlib import Path

root = Path(os.environ["PROJECT_ROOT"])

values = {
    "APP_NAME": "YouTube AI Video Generator",
    "APP_URL": "http://127.0.0.1:8000",
    "SECRET_KEY": os.environ["SECRET_KEY"],
    "SETTINGS_ENCRYPTION_KEY": os.environ["FERNET_KEY"],
    "ADMIN_USERNAME": "admin",
    "ADMIN_EMAIL": "admin@localhost.local",
    "INITIAL_ADMIN_PASSWORD": os.environ["GENERATED_ADMIN_PASSWORD"],
    "SMTP_HOST": "",
    "SMTP_PORT": "587",
    "SMTP_USERNAME": "",
    "SMTP_PASSWORD": "",
    "SMTP_USE_TLS": "true",
    "POSTGRES_DB": "",
    "POSTGRES_USER": "",
    "POSTGRES_PASSWORD": "",
    "DATABASE_URL": f"sqlite:///{root}/backend/data/app.db",
    "REDIS_URL": "redis://127.0.0.1:6379/0",
    "SESSION_DAYS": "7",
    "DEFAULT_DURATION_MINUTES": "10",
    "DEFAULT_LANGUAGE": "English",
    "DEFAULT_VOICE": "male",
    "OLLAMA_URL": "http://127.0.0.1:11434",
    "OLLAMA_MODEL": os.environ["OLLAMA_MODEL"],
}

content = "\n".join(
    f"{key}={json.dumps(value)}"
    for key, value in values.items()
)

(root / ".env").write_text(content + "\n")
PYENV

    chown "$APP_USER:$APP_GROUP" "$ENV_FILE"
    chmod 600 "$ENV_FILE"
else
    log "Existing or recovered .env preserved"
fi

log "Updating portable database path"

PROJECT_ROOT="$PROJECT_ROOT" \
ENV_FILE="$ENV_FILE" \
"$PYTHON" - <<'PYDB'
import json
import os
from pathlib import Path

path = Path(os.environ["ENV_FILE"])
root = Path(os.environ["PROJECT_ROOT"])
database_url = f"sqlite:///{root}/backend/data/app.db"

lines = path.read_text().splitlines()
updated = []
found = False

for line in lines:
    if line.startswith("DATABASE_URL="):
        updated.append(f"DATABASE_URL={json.dumps(database_url)}")
        found = True
    else:
        updated.append(line)

if not found:
    updated.append(f"DATABASE_URL={json.dumps(database_url)}")

path.write_text("\n".join(updated) + "\n")
PYDB

chown "$APP_USER:$APP_GROUP" "$ENV_FILE"
chmod 600 "$ENV_FILE"

log "Initializing database and administrator"

run_as_user env \
    YOUTUBE_AI_PROJECT_ROOT="$PROJECT_ROOT" \
    YOUTUBE_AI_MODEL_ROOT="$MODEL_ROOT" \
    PYTHONPATH="$PROJECT_ROOT/backend" \
    "$PYTHON" -m app.init_db

chown "$APP_USER:$APP_GROUP" \
    "$PROJECT_ROOT/backend/data/app.db"

ENV_FILE="$ENV_FILE" "$PYTHON" - <<'PYCLEAR'
import os
from pathlib import Path

path = Path(os.environ["ENV_FILE"])
lines = path.read_text().splitlines()

lines = [
    'INITIAL_ADMIN_PASSWORD=""'
    if line.startswith("INITIAL_ADMIN_PASSWORD=")
    else line
    for line in lines
]

path.write_text("\n".join(lines) + "\n")
PYCLEAR

chown "$APP_USER:$APP_GROUP" "$ENV_FILE"
chmod 600 "$ENV_FILE"

FLUX_DIR="$MODEL_ROOT/flux1-schnell"
HF_TOKEN_FILE="$APP_HOME/.cache/huggingface/token"

if [[ ! -f "$FLUX_DIR/model_index.json" ]]; then
    [[ -s "$HF_TOKEN_FILE" ]] || \
        fail "Hugging Face token is missing from the recovery backup."

    log "Downloading FLUX.1-schnell"

    run_as_user env \
        MODEL_ROOT="$MODEL_ROOT" \
        HF_TOKEN_FILE="$HF_TOKEN_FILE" \
        HF_HOME="$MODEL_ROOT/huggingface" \
        "$PYTHON" - <<'PYFLUX'
import os
from pathlib import Path
from huggingface_hub import snapshot_download

model_root = Path(os.environ["MODEL_ROOT"])
token_file = Path(os.environ["HF_TOKEN_FILE"])
target = model_root / "flux1-schnell"

token = token_file.read_text().strip()

if not token:
    raise SystemExit("Hugging Face token file is empty.")

target.mkdir(parents=True, exist_ok=True)

snapshot_download(
    repo_id="black-forest-labs/FLUX.1-schnell",
    local_dir=str(target),
    token=token,
    max_workers=4,
)
PYFLUX
else
    log "Existing FLUX model preserved"
fi

[[ -f "$FLUX_DIR/model_index.json" ]] || \
    fail "FLUX model download is incomplete."

log "Installing permanent dashboard service"

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=YouTube AI Video Generator
After=network-online.target redis-server.service ollama.service
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$PROJECT_ROOT
Environment=PYTHONPATH=$PROJECT_ROOT/backend
Environment=YOUTUBE_AI_PROJECT_ROOT=$PROJECT_ROOT
Environment=YOUTUBE_AI_MODEL_ROOT=$MODEL_ROOT
Environment=HF_TOKEN_PATH=$APP_HOME/.cache/huggingface/token
Environment=LD_LIBRARY_PATH=$VENV/lib/python3.12/site-packages/nvidia/cublas/lib:$VENV/lib/python3.12/site-packages/nvidia/cudnn/lib
ExecStart=$VENV/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

log "Checking dashboard"

for _ in $(seq 1 90); do
    if curl -fsS http://127.0.0.1:8000/health >/dev/null 2>&1; then
        break
    fi

    sleep 2
done

curl -fsS http://127.0.0.1:8000/health >/dev/null || {
    journalctl -u "$SERVICE_NAME" -n 100 --no-pager || true
    fail "Dashboard service failed."
}

log "Running final checks"

curl -fsS http://127.0.0.1:8000/health
echo

redis-cli ping

ollama list | grep -F "$OLLAMA_MODEL" >/dev/null || \
    fail "Ollama model is missing."

APP_URL_DISPLAY="$(
    ENV_FILE="$ENV_FILE" "$PYTHON" - <<'PYURL'
import json
import os
from pathlib import Path

path = Path(os.environ["ENV_FILE"])

for line in path.read_text().splitlines():
    if line.startswith("APP_URL="):
        raw = line.split("=", 1)[1]

        try:
            print(json.loads(raw))
        except Exception:
            print(raw.strip().strip('"'))

        break
else:
    print("http://127.0.0.1:8000")
PYURL
)"

echo
echo "INSTALLATION_COMPLETE"
echo "Dashboard: $APP_URL_DISPLAY"
echo "Service: $SERVICE_NAME"
echo "Application user: $APP_USER"

if [[ "$RECOVERY_RESTORED" == "true" ]]; then
    echo "Environment and database restored from GitHub recovery backup."
fi

if [[ -n "$GENERATED_ADMIN_PASSWORD" ]]; then
    echo
    echo "Fresh administrator username: admin"
    echo "Fresh administrator password: $GENERATED_ADMIN_PASSWORD"
    echo "Save this password now. It will not be shown again."
fi
